package paola.rivera.programacinpaola

class Calculadora {
    fun sumar(num1: Int, num2: Int): Int{
        val resultado = num1 + num2
        return resultado
    }
}

